#import <Flutter/Flutter.h>

@interface AudioplayersPlugin : NSObject<FlutterPlugin>
@end
