#import <FlutterMacOS/FlutterMacOS.h>

@interface AudioplayersPlugin : NSObject<FlutterPlugin>
@end
